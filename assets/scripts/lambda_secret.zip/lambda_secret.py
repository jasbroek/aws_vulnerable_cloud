def handler(event, context):
    return "You got me"